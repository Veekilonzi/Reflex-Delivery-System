# Reflex: System Architecture Document
# OWNER: Member 5 (QA Testing & Technical Documentation)

## 1. Executive Overview
Reflex is a synchronized delivery tracking and proof-of-delivery ledger designed specifically for small urban retailers in Kenya. It coordinates three distinct personas (Retailer Staff, Dispatcher, Field Rider) through a single transactional state engine.

---

## 2. Architecture Pattern: Monolithic Layered REST API

```
┌──────────────────────────────────────────────────────────┐
│                   Presentation Layer                     │
│  • HTML5 Single Page App (index.html + styles.css)       │
│  • 4 View Modes (Executive All, Retailer, Dispatch, Rider)│
└────────────────────────────┬─────────────────────────────┘
                             │ JSON REST + HTTP Polling (4s)
                             ▼
┌──────────────────────────────────────────────────────────┐
│                   Application Layer                      │
│  • Flask REST API Gateway (backend/app.py)               │
│  • Persona Route Handlers & Input Validators             │
└────────────────────────────┬─────────────────────────────┘
                             │ Python In-Process Calls
                             ▼
┌──────────────────────────────────────────────────────────┐
│             Business Logic & State Machine Engine        │
│  • Finite State Machine (PENDING → ASSIGNED → DELIVERED) │
│  • SMS 4-Digit OTP Challenge-Response Verifier           │
│  • Concurrency Row-Level Assignment Locks (backend/db.py)│
└──────────────────────────────────────────────────────────┘
```

---

## 3. REST API Specification

| Method | Endpoint | Persona | Purpose |
|:---|:---|:---|:---|
| `GET` | `/` | All | Serves interactive SPA dashboard |
| `GET` | `/api/orders` | Retailer / Audit | List all orders with optional `?status=` filter |
| `POST` | `/api/orders` | Retailer | Create new delivery request + generate OTP |
| `GET` | `/api/orders/<id>/tracking` | Retailer / Customer | Real-time audit trail & rider assignment |
| `GET` | `/api/dispatch/unassigned` | Dispatcher | Open order queue & available fleet status |
| `POST` | `/api/dispatch/assign` | Dispatcher | Assigns order to rider (guarded against re-assignment) |
| `GET` | `/api/riders/<id>/tasks` | Rider | Active assigned tasks for specific rider |
| `POST` | `/api/riders/pickup` | Rider | Confirms parcel pickup (`ASSIGNED` → `PICKED_UP`) |
| `POST` | `/api/riders/deliver` | Rider | Validates customer OTP (`PICKED_UP` → `DELIVERED`) |
| `POST` | `/api/system/reset` | All (Demo) | Resets state to clean baseline seed data |

---

## 4. Finite State Machine (Order Lifecycle)

```
[ PENDING_DISPATCH ] ──(Dispatcher Assigns)──> [ ASSIGNED ]
                                                    │
                                         (Rider Confirms Pickup)
                                                    │
                                                    ▼
[ DELIVERED ] <──(Valid Customer OTP PIN)─── [ PICKED_UP ]
```

* **Guards**:
  * An order cannot be assigned if not in `PENDING_DISPATCH`.
  * An order cannot be picked up unless assigned to that specific rider.
  * An order cannot be delivered without matching the exact 4-digit OTP generated at creation.

---

## 5. Agile Scrum Implementation

* **Sprint Iterations**: 5-Day rapid readiness sprint with mid-sprint pivot adaptability.
* **Sprint Review**: Verified via automated 8-case test suite (`tests/test_reflex.py`).
